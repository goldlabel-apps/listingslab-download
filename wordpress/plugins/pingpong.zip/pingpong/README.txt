
          _____ _                                           
    ____ |  __ (_)                                          
   / __ \| |__) | _ __   __ _ _ __   ___  _ __   __ _       
  / / _` |  ___/ | '_ \ / _` | '_ \ / _ \| '_ \ / _` |      
 | | (_| | |   | | | | | (_| | |_) | (_) | | | | (_| |      
  \ \__,_|_|   |_|_| |_|\__, | .__/ \___/|_| |_|\__, |      
   \____/                __/ | |                 __/ |      
  _             _ _     |___/|_|              _ |___/ _     
 | |           | (_)   | | (_)               | |     | |    
 | |__  _   _  | |_ ___| |_ _ _ __   __ _ ___| | __ _| |__  
 | '_ \| | | | | | / __| __| | '_ \ / _` / __| |/ _` | '_ \ 
 | |_) | |_| | | | \__ \ |_| | | | | (_| \__ \ | (_| | |_) |
 |_.__/ \__, | |_|_|___/\__|_|_| |_|\__, |___/_|\__,_|_.__/ 
         __/ |                       __/ |                  
        |___/                       |___/                   


=== @Pingpong ===

Stable tag: 1.7.7
Contributors: listingslab 
Tags: react, listingslab, people
Requires at least: 5.6
Tested up to: 5.6
Requires PHP: 5.6.20
License: MIT
License URI: https://opensource.org/licenses/MIT 

== Description == 

Betterer WordPress

== Installation ==

1. Download the latest [zip](https://github.com/listingslab-software/listingslab-download/raw/master/wordpress/plugins/pingpong.zip)
2. Navigate to the [Add Plugins](/wp-admin/plugin-install.php) page in wp-admin
3. Tap Upload Plugin and select the zip file you downloaded
4. Upload and activate 
5. Configure the plugin on first run

== Frequently Asked Questions == 

= Wow, how does it work? = 

With real time NoSQL database updates. Without cookies.

= Is is Open Source? = 

Parts of it are, yes

= What is a 'host'?=

A unique WordPress install

= What is a 'Person'? =

A unique device, ip / host combination

= Is it secure? =

It's as secure as the WordPress behind it

= Why should I try this? = 

Well, it's something a bit different innit. 
What have you got to lose?

= I don't like it or it doesn't work, can you change it please? = 

Sure. Please raise a [bug/issue](https://github.com/listingslab-software/listingslab-download/issues/new) 
Better still raise a Pull Request with a solution :)
