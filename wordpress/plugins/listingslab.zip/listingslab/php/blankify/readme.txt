=== Generic ===

Contributors: listingslab, bhadaway
Theme link: https://listingslab.com
Tags: PWA
Stable tag: 14.4.8
Requires at least: 5.0
Tested up to: 5.7
Stable tag: trunk
License: GNU General Public License v3 or Later
License URI: https://www.gnu.org/licenses/gpl.html

A fully responsive starter theme for designers and developers.

== Description ==

Hack this theme up how you like, starting with making it your own:
Open in your favorite editor and Find and Replace "blank-theme" with your own theme slug.

Enjoy!

=== Notes ===

- This is a starter theme.
- Use this tool how you like.
- Attribution is NOT required.

=== License ===

Generic WordPress Theme © 2015-2021 GenericTools
Generic is distributed under the terms of the GNU GPL

The Generic theme package and all files contained within are distributed under the terms of the GNU GPL v3 or Later (https://www.gnu.org/licenses/gpl.html).