<a href="https://github.com/listingslab-software/listingslab-download" 
   target="_blank" 
   ref="noreferrer"
   style="width: 25px; height: 25px;">
   <img width="25" height="25" src="<?php echo plugins_url('/listingslab/php/assets/png/github.png'); ?>" />
</a>
