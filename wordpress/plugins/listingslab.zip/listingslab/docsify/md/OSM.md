## Open Source Management 

OSM or Open Source Management is a methodology based on sound Agile concepts. Agile is clearly the only show in town, but there are as many methods of implementing it as there are companies.

As contractors we've worked in aevery concievable size and shape of professional software development environments 

#### (OSM) 
或开源管理是一种基于健全的敏捷概念的方法论。 敏捷显然是镇上唯一的展示，但实施它的方法与公司一样多。 作为承包商，我们在各种可能的规模和形状的专业软件开发环境中工作
