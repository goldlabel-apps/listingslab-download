import Docsify from './Docsify'

export {
	Docsify,
}