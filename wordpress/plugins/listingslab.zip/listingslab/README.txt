=== @listingslab ===

Contributors: listingslab 
Stable tag: 14.9.3
Tags: pwa, react, listingslab
Requires at least: 5.6
Tested up to: 5.6
Requires PHP: 5.6.20
License: MIT
License URI: https://opensource.org/licenses/MIT 

== Description == 

@listingslab takes any tired old WordPress site and without changing the underlying original, magically adds a Progressive WordPress App over it

== Current Dev == 

14.9.3 NO HOST NO PLAY Release

#### wp-pwa
	* - FIRST load thisHost from the API. If no host... no play
	- load wp-json content
	- Add ability to turn PWA off and view/use wordpress site beneath
	- Add pingpong panel
	- Add main content panel
	- Add Stalker panel
	- Add link to GitHub
	- Add link to api
	- Add Clockwork

#### wp-admin
	- FIRST load thisHost from the API. If no host... setup
	*- Url param id open the app to person 
	
	- Add ability to update name
	- 'boot' persons instead of deleting them
	*- Change TimeMachine Graphic to smiley	
	
#### api
	- /notify do not notify on google search
		notify on special occasions only

	- dynamic hosts endpoint 
		GET
		/hosts (all hosts, protected)
		/hosts/:host (single host)
		POST
		/host/create
		/host/update
		/host/delete


= Roadmap =

Install Salient-edited on PIJS 

Update plugin urls

https://pijs.xyz/wp-admin/plugin-install.php
https://thebay.site/wp-admin/plugin-install.php
https://listingslab.com/wp-admin/plugin-install.php
https://localify.world/wp-admin/plugin-install.php
https://commercify.store/wp-admin/plugin-install.php

== Project Management ==

- [Download Latest](https://github.com/listingslab-software/listingslab-download) 
- [New Issue](https://github.com/listingslab-software/listingslab/issues/new/choose) 
- [Kanban Board](https://github.com/orgs/listingslab-software/projects/14?fullscreen=true&card_filter_query=label%3A%40listingslab) 

== Installation ==

1. Download the latest [zip](https://github.com/listingslab-software/listingslab/raw/develop/listingslab.zip)
2. Navigate to the [Add Plugins](/wp-admin/plugin-install.php) page in wp-admin
3. Tap Upload Plugin and select the zip file you downloaded
4. Upload and activate 
5. Configure the plugin on first run

== Frequently Asked Questions == 

= Wow, how does it work? = 

Well, it's something a bit different innit. What have you got to lose?

= Is is Open Source? = 

Parts of it are, yes
 
= Why should I try this? = 

Well, it's something a bit different innit. What have you got to lose?

= I don't like it or it doesn't work, can you change it please? = 

Sure. Raise a [bug](https://github.com/listingslab-software/listingslab/issues/new/choose) 
Better still raise a Pull Request with a solution
