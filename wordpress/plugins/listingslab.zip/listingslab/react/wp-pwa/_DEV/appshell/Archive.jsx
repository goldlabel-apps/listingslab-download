import React from 'react'
import clsx from 'clsx'
import {
    makeStyles,
    Grid,
    Card,
    CardHeader,
    CardActionArea,
    Typography,
} from '@material-ui/core/'
import { 
  getList,
  selectContent,
} from '../redux/wordpress/actions'

const useStyles = makeStyles((theme) => ({
  archive: {
    marginTop: theme.spacing(),
  },
  card:{
    // minHeight: 100,
    margin: theme.spacing(),
    background: 'white',
  }
}))

export default function Archive() {

  const classes = useStyles() 
  const list = getList({ filter: `products` })
  if (!list) return null

  return <div className={ clsx(classes.archive) }> 
            <Grid container>
              { list.map( ( item, i ) => {
                if (i===0) console.log ('item', item)
                return <Grid key={`post_${i}`} item xs={ 12 } sm={ 6 } >
                         <Card className={ clsx( classes.card )}>
                         <CardActionArea
                           onClick={ ( e ) => {
                             e.preventDefault()
                             selectContent( item )
                           }}>
                           <CardHeader 
                             disableTypography
                             title={ <Typography variant={ `body1` }>
                                       { item.name }
                                     </Typography>}
                             
                           />
                           </CardActionArea>
                        </Card>
                     </Grid>
              }) }
             </Grid>
          </div>
}

/*
<pre>{ JSON.stringify(wordpressSlice, null, 2 ) }</pre>

subheader={ <Typography variant={ `body2` }>
                                             { moment(item.modified).fromNow() }
                                           </Typography>}
*/