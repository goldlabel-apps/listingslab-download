import React from 'react'
import clsx from 'clsx'
import { useSelector } from 'react-redux'
import {
    makeStyles,
    Card,
    CardHeader,
    CardContent,
    Typography,
    IconButton,
} from '@material-ui/core/'
import { Icon } from '../theme'
import {
  navigateTo,
} from '../redux/router/actions'
import {
  getContentById,
} from '../redux/wordpress/actions'

const useStyles = makeStyles((theme) => ({
  single: {
    background: 'white',
    marginLeft: theme.spacing(),
    marginRight: theme.spacing(),
  },
  flex: {
    display: 'flex',
  },
  heading:{
    fontWeight: 'lighter',
  },
  image: {
    maxWidth: '100%',
    marginBottom: theme.spacing(),
  },
}))

export default function Single() {
  
  const classes = useStyles()
  const wordpressSlice = useSelector(state => state.wordpress)   
  const {
    selectedId,
  } = wordpressSlice  

  const content = getContentById ( selectedId )

  if ( !content ) return null

  const { 
    type, 
  } = content

  

  let title = `title`
  let subheader = `subheader`
  let body = `body`
  
  if (type === `product`){
    title = content.data.name 
    subheader = `$AU ${content.data.price}`
    body = content.data.description
  }

  if (type === `post` || type === 'page') {
    title = content.data.title.rendered
    subheader = content.data.excerpt.rendered
    body = content.data.description
  }

  return <Card className={clsx( classes.single )}>
            <CardHeader
              title={ title }
              subheader={ <div dangerouslySetInnerHTML={ {__html: subheader } } /> } 
              action={ <IconButton
                          onClick={ ( e ) => {
                            e.preventDefault()
                            navigateTo( `https://thebay.site/wp-admin/post.php?post=${selectedId}&action=edit`,`_blank`)
                          }}>
                        <Icon icon={ `edit`} />
                       </IconButton> }
            />
            <CardContent>
              <Typography component={ `div`} variant={ `body1` } gutterBottom>
                <div dangerouslySetInnerHTML={ {__html: body} } />
              </Typography>
              
            </CardContent>
          </Card>
}




/*

<pre>
                { JSON.stringify( content, null,2 ) }
              </pre>
              


            <CardContent>
              <Typography component={ `div`} variant={ `body1` } gutterBottom>
                <div dangerouslySetInnerHTML={ {__html: html} } />
              </Typography>
            </CardContent>


<pre>
            { JSON.stringify( content, null,2 ) }
          </pre>

<img
                align={`left`}
                className={classes.image}
                src="http://localhost:3000/jpg/puppy.jpg"
                alt="default"
              />

*/
