import React from 'react'
import  { 
  changeRoute
} from '../redux/router/actions'
import {
    makeStyles,
    BottomNavigation,
    BottomNavigationAction,
    AppBar,
    Toolbar,
} from '@material-ui/core/'
import { Icon } from '../theme'

const useStyles = makeStyles((theme) => ({
  appBar: {
    top: 'auto',
    bottom: 0,
    // background: 'none',
    boxShadow: 'none',
  },
  toolbar:{
    background: theme.palette.background.paper,
  },
  fullW: {
    width: '100%',
  },
}))

export default function BottomNav() {
  const classes = useStyles()
  const [value, setValue] = React.useState(0)

  return <React.Fragment>
          <AppBar position="fixed" color="secondary" className={classes.appBar}>
            <Toolbar  className={classes.toolbar}>
              <BottomNavigation
                showLabels
                value={value}
                onChange={(event, newValue) => {
                  setValue(newValue)
                }}
                className={classes.fullW}>
                <BottomNavigationAction 
                  label="Work" 
                  icon={ <Icon icon={ `work` } /> } 
                  onClick={ ( e ) => {
                    changeRoute('/work/')
                  }}
                />

                <BottomNavigationAction 
                  label="Life" 
                  icon={ <Icon icon={ `life` } /> } 
                  onClick={ ( e ) => {
                    changeRoute('/life/')
                  }}
                />

                <BottomNavigationAction 
                  label="Balance" 
                  icon={ <Icon icon={ `balance` } /> } 
                  onClick={ ( e ) => {
                    changeRoute('/balance/')
                  }}
                />

              </BottomNavigation>
                </Toolbar>
          </AppBar>
        </React.Fragment>
  
}
