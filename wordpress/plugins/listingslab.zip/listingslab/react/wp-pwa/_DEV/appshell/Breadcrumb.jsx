import React from 'react'
import { useSelector } from 'react-redux'
import {
    makeStyles,
    IconButton,
    ButtonBase,
    Typography,
} from '@material-ui/core/'
import { Icon } from '../theme'

const useStyles = makeStyles((theme) => ({
  mightyBtn:{
    padding: theme.spacing(),
    color: 'rgba( 0,0,0,0.33 )',
    // border: '1px solid red',
  },
  separator:{
    color: 'rgba( 0,0,0,0.11 )',
  },
  breadcrumbMobile: {
    display: 'flex',
    // paddingLeft: theme.spacing(),
    // paddingRight: theme.spacing(),
    // marginTop: -theme.spacing(2),
  },
  breadcrumb: {
    // border: '1px solid green',
    display: 'flex',
    // paddingLeft: theme.spacing(),
    // paddingRight: theme.spacing(),
    marginRight: theme.spacing(),
    marginLeft: theme.spacing(),
  },
  link: {
    display: 'flex',
  },
  grow: {
    flexGrow: 1,
  },
  icon: {
    marginRight: theme.spacing(),
    width: 20,
    height: 20,
  },

}))

const makeSeparator = classes => {
  return <span className={ classes.separator }>|</span>
}

export default function Breadcrumb() {
  const classes = useStyles()
  // const appSlice = useSelector( state => state.app ) 
  const routerSlice = useSelector( state => state.router ) 
  // const {
  //   isMobile,
  // } = appSlice
  const {
    breadcrumb,
  } = routerSlice

  // console.log ('breadcrumb', breadcrumb)
  const isMobile = false

  if ( isMobile ) return <div className={ classes.breadcrumbMobile }>
                              <IconButton
                                color={ `primary` }
                                size={ `small` }
                                onClick={ () => {
                                  console.log( 'open mobile bc' )
                                }}>
                                <Icon icon={ `right` } color={ `primary` } />
                              </IconButton>
                        </div>

  return <React.Fragment>
            <div className={ classes.breadcrumb }>
              { breadcrumb.map( ( item, i ) => {
                 const {
                  label,
                } = item
                return <div key={`breadcrumb_${i}`}>
                            <ButtonBase
                              className={ classes.mightyBtn }
                              onClick={ ( e ) => {
                                console.log (item.label, 'clicked')
                              }}>
                              <Typography variant={ `body2` }>
                              { label }
                              </Typography>
                            </ButtonBase>
                            { makeSeparator(classes) }
                       </div>
              })}
            </div>
          </React.Fragment>
}



/*

<Tooltip title={ tooltip }>
          </Tooltip>
            <IconButton
              color={ `primary` }
              onClick={ () => {
                console.log( 'open mobile bc' )
              }}>
                <Icon icon={ `right` } color={ `primary` } />
            </IconButton>
          </Tooltip>
<div className={ classes.grow } />

*/