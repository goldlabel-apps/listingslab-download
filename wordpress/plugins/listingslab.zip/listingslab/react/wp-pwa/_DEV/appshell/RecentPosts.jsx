import React from 'react'
import clsx from 'clsx'
import { useSelector } from 'react-redux'
import {
    makeStyles,
    ListItem,
    List,
    ListItemText,
    ListItemAvatar,
} from '@material-ui/core/'
import {
  CollapseBox,
} from '../components'
import {
  selectContent,
} from '../redux/wordpress/actions'
import { Icon } from '../theme'

const useStyles = makeStyles((theme) => ({
  recentPosts: {
    // background: 'white',
  },
}))

export default function RecentPosts() {

  const classes = useStyles() 
  const wordpressSlice = useSelector(state => state.wordpress)
  const {
    bus,
  } = wordpressSlice
  const {
    posts,
    pages,
  } = bus

  let listBlog = null
  if ( posts.list ){
    listBlog = <List dense> 
                    { posts.list.map( ( item, i ) => { 
                        //if ( i > 8 ) return null
                        return <ListItem 
                                button 
                                key={ `post_${i}` } 
                                onClick={ ( e ) => {
                                   e.preventDefault()
                                   selectContent(item)
                                 }} >
                                 <ListItemAvatar>
                                   <Icon icon={ `right` } color={ `secondary` } />
                                 </ListItemAvatar>
                                <ListItemText 
                                  primary={ item.title.rendered }
                                />
                              </ListItem>
                     })}
                  </List> 
  }


    let listPages = null
    if ( pages.list ){
    listPages = <List dense> 
                    { pages.list.map( ( item, i ) => { 
                        //if ( i > 8 ) return null
                        return <ListItem 
                                button 
                                key={ `post_${i}` } 
                                onClick={ ( e ) => {
                                   e.preventDefault()
                                   selectContent(item)
                                 }} >
                                 <ListItemAvatar>
                                   <Icon icon={ `right` } color={ `secondary` } />
                                 </ListItemAvatar>
                                <ListItemText 
                                  primary={ item.title.rendered }
                                />
                              </ListItem>
                     })}
                  </List> 
  }


  

  return <React.Fragment> 

            <CollapseBox title={ `Pages` } defaultOpen={ true } className={ classes.recentPosts }>
                <div className={ clsx( classes.collapsed )}>
                  { pages.list ?  listPages : null }
                  </div>
            </CollapseBox>
            
            <CollapseBox title={ `Blog` } defaultOpen={ true } className={ classes.recentPosts }>
                <div className={ clsx( classes.collapsed )}>
                  { posts.list ?  listBlog : null }
                  </div>
            </CollapseBox>

            

         </React.Fragment>
}
