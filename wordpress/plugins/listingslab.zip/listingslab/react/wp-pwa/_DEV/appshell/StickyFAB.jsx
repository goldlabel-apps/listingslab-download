import React from 'react'
import {
    makeStyles,
    Fab,
} from '@material-ui/core/'

import { Icon } from '../theme'

const useStyles = makeStyles((theme) => ({
  grow: {
    flexGrow: 1,
  },
  fabButton: {
    position: 'absolute',
    bottom: 65,
    right: theme.spacing(2),
    boxShadow: 'none',
    margin: '0 auto',
  },
}))

export default function StickyFAB() {

  const classes = useStyles()

  return <React.Fragment>
              <Fab className={classes.fabButton}
                onClick={ ( e ) => {
                  console.log ('home, james')
                }}>
                <Icon icon={ `home` } />
              </Fab>
        </React.Fragment>
}
