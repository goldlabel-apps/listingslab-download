import React from 'react' 
import clsx from 'clsx' 
// import { useSelector } from 'react-redux'
import {
    makeStyles,
    Grid,
} from '@material-ui/core/'
import { 
  Pingpong,
} from './'
// import { Icon } from '../theme'

const useStyles = makeStyles( theme => ({
  contentDisplay: {
    padding: theme.spacing(2),
    marginBottom: 70,
  },
}))

export default function Content() {
  
  const classes = useStyles()

  return <div className={ clsx( classes.contentDisplay )}>
            <Grid container>
              <Grid item xs={ 12 }>
                <Pingpong />
              </Grid>            
            </Grid>
          </div>
}
