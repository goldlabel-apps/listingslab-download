import React from 'react'
import clsx from 'clsx'
import { useSelector } from 'react-redux' 
import {
    makeStyles,
    Card,
    CardHeader,
    CardContent,
    // Typography,
} from '@material-ui/core/'
import { Icon } from '../theme'

const useStyles = makeStyles(theme => ({
	debugger:{
		margin: theme.spacing(),
		background: 'rgba(255, 255, 255, 1)',
		// boxShadow: 'none',
		// borderRadius: 'none',
		fontSize: 10,
	},
}))

export default function Debugger( props ) {
	
	const classes = useStyles() 
	const wordpressSlice = useSelector( state => state.wordpress )
	const on = false
	if (!on) return null
		
	return	<Card className={ clsx( classes.debugger ) }>
				<CardHeader 
					avatar={ <Icon icon={ `bug` } color={ `primary` } /> }
					title={ `wordpressSlice` }
				/>
				<CardContent>
					<pre>
						{ JSON.stringify( wordpressSlice.bus, null, 2) }
					</pre>
				</CardContent>
			</Card>
}


/*

const routerSlice = useSelector( state => state.router )

<CardContent>
	<Typography variant={ `h6` } >
		routerSlice
	</Typography>
	<pre>
		{ JSON.stringify( routerSlice, null, 2) }
	</pre>
</CardContent>
*/