import React from 'react'
import { makeStyles } from '@material-ui/core/styles'
import Accordion from '@material-ui/core/Accordion'
import AccordionSummary from '@material-ui/core/AccordionSummary'
import AccordionDetails from '@material-ui/core/AccordionDetails'
import Typography from '@material-ui/core/Typography'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'

const useStyles = makeStyles((theme) => ({
  collapseBox: {
    // width: '100%',
    // marginTop: theme.spacing( 2 ),
  },
  card: {
    border: 'none',
    boxShadow: 'none',
    background: 'white',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },
}))

export default function CollapseBox( props ) {

  const classes = useStyles()
  const {
    title,
    defaultOpen,
    children,
  } = props

  return <div className={classes.collapseBox}>
          <Accordion defaultExpanded={ defaultOpen } color={ `primary` } className={classes.card}>
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              aria-controls="panel1a-content"
              id="panel1a-header"
            >
              <Typography className={classes.heading}>
                { title }
              </Typography>
            </AccordionSummary>
            <AccordionDetails>
              { children }
            </AccordionDetails>
          </Accordion>
          </div>
}
