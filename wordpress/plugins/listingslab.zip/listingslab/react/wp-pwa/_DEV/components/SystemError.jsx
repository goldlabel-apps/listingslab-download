import React from 'react'
import { useSelector } from 'react-redux'
import {
    makeStyles,
    Typography,
    Button,
    Dialog,
} from '@material-ui/core/'
import MuiAlert from '@material-ui/lab/Alert'
import { AlertTitle } from '@material-ui/lab'
import {
  navigateTo,
} from '../redux/router/actions'
import { 
  Icon,
} from '../theme'

const useStyles = makeStyles((theme) => ({
  systemError: {
    overflow: 'hidden',
    margin: theme.spacing()
  },
  min: {
    minWidth: 350,
  },
  reloadBtn: {
    marginTop: theme.spacing(),
  },
  raw: {
    fontSize: '10px',
    overflow: 'hidden',
  },
  btnTxt:{
    color: 'white',
    marginRight: theme.spacing(),
    marginLeft: theme.spacing(),
  },
}))

function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />
}

export default function SystemError() {
  
  const classes = useStyles()
  const appSlice = useSelector(state => state.app)
  const {
    error,
  } = appSlice
  if ( !error ) return null

  

  return <Dialog open className={ classes.systemError } >
            <div className={ classes.min }>
              <Alert 
                variant={`filled`}
                severity={ `error` }>
                  <AlertTitle className={classes.titleTxt}>
                    <Typography variant={ `h6` } gutterBottom >
                      App has crashed.
                    </Typography>
                    <Typography variant={ `body1` } gutterBottom >
                      { error.toString() }
                    </Typography>
                  </AlertTitle>
                  <Button 
                      fullWidth
                      className={ classes.reloadBtn }
                      variant={ `contained` }
                      color={ `primary` }
                      onClick={ (e) => {
                        e.preventDefault()
                        navigateTo(`/`, `_self`)
                      }}>
                      <Icon icon={ `restart` } color={`secondary`} /> 
                      <span className={ classes.btnTxt }>Reload</span>                   
                    </Button>
              </Alert>
            </div>
        </Dialog>
}

/*

{ rawError ? <pre className={ classes.raw }>
                    { JSON.stringify( error, null, 2 ) }
                  </pre> : null }
<IconButton 
                    className={ classes.mightyBtn }
                    variant={ `contained` }
                    color={ `secondary` }
                    onClick={ (e) => {
                      e.preventDefault()
                      setRawError( !rawError )
                    }}>
                    <Icon icon={ `code`} color={`primary`} />
                  </IconButton>
const [rawError, setRawError] = React.useState( false )

*/