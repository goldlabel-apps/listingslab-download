import React from 'react'
import clsx from 'clsx'
import { useSelector } from 'react-redux'
import {
    makeStyles,
    CardActionArea,
    CardContent,
    CardHeader,
    Grid,
    IconButton,
} from '@material-ui/core/'
import { getList } from '../redux/wordpress/actions'
import { 
  changePathname,
  navigateTo,
} from '../redux/router/actions'
import { selectContent } from '../redux/wordpress/actions'
import { Icon } from '../theme'

const useStyles = makeStyles((theme) => ({
  card: {
    background: 'white',
    // margin: theme.spacing(),
  },
}))

export default function Featured() {
  
  const classes = useStyles()
  const list = getList( {filter: `featured-products` } )
  const appSlice = useSelector( state => state.app ) 
  const {
    editMode,
  } = appSlice
  const wordpressSlice = useSelector(state => state.wordpress) 
  const {
    wpData,
  } = wordpressSlice
  const {
    isLoggedIn,
  } = wpData


  if ( !list.length ) return null


 
  return <div className={ classes.featured } >
          
          <CardContent>
            <Grid container>
              
                { list.map(( item,i ) => {
                  const { 
                    id,
                    permalink,
                    name,
                    short_description,
                  } = item
                  const pathname = `/${permalink.replace( process.env.REACT_APP_WORDPRESS, ``)}`
                  

                  return <Grid item xs={ 12 } md={ 6 } key={ `front_${i}`}>
                          <div className={ clsx( classes.card )}>
                             <CardActionArea
                               component={ `div` }
                               onClick={ ( e ) => {
                                 e.preventDefault()
                                  changePathname( pathname )
                                  selectContent( item )
                               }}>
                               <CardHeader 
                                 title={ name }
                                 subheader={ <div dangerouslySetInnerHTML={ { __html: short_description } } /> }
                                 action={ isLoggedIn && editMode ? <IconButton
                                             onClick={ ( e ) => {
                                               e.preventDefault()
                                               navigateTo( `https://thebay.site/wp-admin/post.php?post=${ id }&action=edit`,`_blank`)
                                             }}>
                                             <Icon icon={ `edit`} color={ `primary` }/>
                                           </IconButton> : null }
                               />
                             </CardActionArea>
                          
                          </div>
                          </Grid>
                        })}
              
            </Grid>
          </CardContent>
        </div>
}

/*
let thumbnailSrc = `/svg/defaultThumbnail.svg`
                  if (item.images){
                    const src = item.images[0].src
                    thumbnailSrc = `${src.slice(0, src.length - 4)}-150x150.jpg`
                  }
action={ <Icon icon={ `featured`} color={ `secondary` } /> }

*/