
# Blank Theme

## Symlink 

> ln [-fs] [-L|-P] source_file target_file

```bash
ln -s ~/Desktop/Node/listingslab/php/blank-theme ~/Desktop/PHP/WordPress/demosite/wp-content/themes
```